//
//  DateHandler.swift
//  MyFirebaseDatabase
//
//  Created by Anthony Rodriguez on 8/16/17.
//  Copyright © 2017 Anthony Rodriguez. All rights reserved.
//

import Foundation

class DataHandler
{
    let currentDateTime = Date()
    
    static let requestComponents:NSCalendar.Unit = [
        NSCalendar.Unit.year,
        NSCalendar.Unit.month,
        NSCalendar.Unit.day,
        NSCalendar.Unit.hour,
        NSCalendar.Unit.minute,
        NSCalendar.Unit.second
    ]
    
    static func getDateTime() -> String?
    {
        let dateTimeComponents = (Calendar.current as NSCalendar).components(requestComponents, from: Date())
        guard let year = dateTimeComponents.year else {return ""}
        guard let month = dateTimeComponents.month else {return ""}
        guard let day = dateTimeComponents.day else {return ""}
        guard let hour = dateTimeComponents.hour else {return ""}
        guard let minute = dateTimeComponents.minute else {return ""}
        guard let seconds = dateTimeComponents.second else {return ""}
        
        let secondsString:String = {
            if seconds >= 10
            {
                return "\(seconds)"
            }
            else
            {
                return "0\(seconds)"
            }
        }()
        
        // Date format
        //2017,10,10,12:00:00
        return "\(year),\(month),\(day),\(hour):\(minute):\(secondsString)"
    }
}
