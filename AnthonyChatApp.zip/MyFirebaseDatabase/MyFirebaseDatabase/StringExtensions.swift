//
//  StringExtensions.swift
//  PizzaMaker
//
//  Created by Anthony Rodriguez on 8/9/17.
//  Copyright © 2017 Anthony Rodriguez. All rights reserved.
//

import Foundation

extension String
{
    func isVaildEmail() -> Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailText = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        return emailText.evaluate(with: self)
    }
}
