//
//  ViewController.swift
//  FirebaseDatabase
//
//  Created by Anthony Rodriguez on 8/16/17.
//  Copyright © 2017 Anthony Rodriguez. All rights reserved.
//

import Foundation
import UIKit
import Firebase

class ViewController: UIViewController
{
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passTextField: UITextField!
    var uid:String?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        emailTextField.delegate = self
        passTextField.delegate = self
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func presentAlert(title:String, message:String)
    {
        let alert = Alert.createAlert(title: title, message: message)
        self.present(alert, animated: true)
    }
    
    func signInToFirebase()
    {
        guard let email = emailTextField.text else {presentAlert(title: "Error", message: "Email should not be empty")
            return
        }
        guard email.isVaildEmail() else {
            presentAlert(title: "Error", message: "Email does not have a valid format")
            return
        }
        guard let password = passTextField.text else {
            presentAlert(title: "Error", message: "Password field should not be empty")
            return
        }
        guard password.characters.count > 5 else {
            presentAlert(title: "Error", message: "Password is too short")
            return
        }
        
        Auth.auth().signIn(withEmail: email, password: password) {
            [unowned self]
            (user, error) in
            guard error == nil else {return}
            guard let user = user else {return}
            self.uid = user.uid
            self.performSegue(withIdentifier: "login", sender: nil)
        }
        //retrieveUserInfo()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "login"
        {
            guard let vc = segue.destination as? ChatViewController else {return}
            vc.uid = self.uid
        }
    }
    
    func retrieveUserInfo()
    {
        guard let uid = self.uid else {return}
        let reference = Database.database().reference()
        let user = reference.child("Users").child(uid)
        user.observeSingleEvent(of: .value, with: {(snapshot) in
            print(snapshot.value as? [String:String] ?? "No value")
        })
    }
    
    func writeToUser()
    {
        guard let uid = self.uid else {return}
        let reference = Database.database().reference()
        let user = reference.child("Users").child(uid)
        user.child("MiddleName").setValue("Another MiddleName")
        
        // Use this for the chat homework
        user.child("DateHandler Date").setValue("Chat Message")
    }
}

extension ViewController: UITextFieldDelegate
{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        guard string == "\n" else {return true}
        textField.resignFirstResponder()
        guard textField === self.passTextField else {return false}
        self.signInToFirebase()
        return false
    }
}
