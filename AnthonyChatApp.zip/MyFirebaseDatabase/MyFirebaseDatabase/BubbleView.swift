//
//  BubbleView.swift
//  CGExample
//
//  Created by Anthony Rodriguez on 8/17/17.
//  Copyright © 2017 Anthony Rodriguez. All rights reserved.
//

import Foundation
import UIKit
import CoreGraphics

@IBDesignable class BubbleView:UIView
{
    @IBInspectable var HeightOfTriangle:CGFloat = 20.0
    @IBInspectable var WidthOfTriangle:CGFloat = 40.0
    @IBInspectable var BorderRadius:CGFloat = 0.0
    @IBInspectable var StrokeWidth:CGFloat = 3.0
    
    override init(frame: CGRect)
    {
        var myFrame = frame
        let label = UILabel(frame: CGRect(x: 5, y: 5, width: frame.size.width - 10, height: frame.size.height - 10))
        label.text = "I am fake text"
        label.font = .systemFont(ofSize: 15)
        label.lineBreakMode = .byWordWrapping
        label.numberOfLines = 0
        
        label.sizeToFit()
        
        myFrame = CGRect(x: frame.minX, y: frame.minY, width: frame.width, height: label.frame.height + 30)
        
        super.init(frame: myFrame)
        self.addSubview(label)
        self.backgroundColor = .white
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        fatalError("init(coder: ) has not been implemented")
    }
    
    override func draw(_ rect: CGRect)
    {
        let context = UIGraphicsGetCurrentContext()
        context?.translateBy(x: 0.0, y: self.bounds.size.height)
        context?.scaleBy(x: 1.0, y: -1.0)
        
        let currentFrame = self.bounds
        context?.setLineJoin(CGLineJoin.round)
        context?.setLineWidth(StrokeWidth)
        context?.setStrokeColor(UIColor.red.cgColor)
        context?.setFillColor(UIColor.green.cgColor)
        
        context?.beginPath()
        
        context?.move(to: CGPoint(x: BorderRadius + StrokeWidth + 0.5, y: StrokeWidth + HeightOfTriangle + 0.5))
        context?.addLine(to: CGPoint(x: round((currentFrame.size.width * 0.5 - WidthOfTriangle * 0.5) + 0.5), y: HeightOfTriangle + StrokeWidth + 0.5))
        context?.addLine(to: CGPoint(x: round((currentFrame.size.width * 0.5) + 0.5), y:StrokeWidth + 0.5))
        context?.addLine(to: CGPoint(x: round((currentFrame.size.width * 0.5 + WidthOfTriangle * 0.5) + 0.5), y: HeightOfTriangle + StrokeWidth + 0.5))
        
        context?.addArc(
            tangent1End: CGPoint(x: currentFrame.size.width - StrokeWidth - 0.5, y: StrokeWidth + HeightOfTriangle + 0.5),
            tangent2End: CGPoint(x: currentFrame.size.width - StrokeWidth - 0.5, y: currentFrame.size.height - StrokeWidth - 0.5),
            radius: BorderRadius - StrokeWidth)
        
        context?.addArc(
            tangent1End: CGPoint(x: currentFrame.size.width - StrokeWidth - 0.5, y: currentFrame.size.height - StrokeWidth - 0.5),
            tangent2End: CGPoint(x: round(currentFrame.size.width * 0.5 + WidthOfTriangle * 0.5) - StrokeWidth + 0.5, y: currentFrame.size.height - StrokeWidth - 0.5),
            radius: BorderRadius - StrokeWidth)
        
        context?.addArc(
            tangent1End: CGPoint(x: StrokeWidth + 0.5, y: currentFrame.size.height - StrokeWidth - 0.5),
            tangent2End: CGPoint(x: StrokeWidth + 0.5, y: HeightOfTriangle + StrokeWidth + 0.5),
            radius: BorderRadius - StrokeWidth)
        
        context?.addArc(
            tangent1End: CGPoint(x: StrokeWidth + 0.5, y: StrokeWidth + HeightOfTriangle + 0.5),
            tangent2End: CGPoint(x: currentFrame.size.width - StrokeWidth - 0.5, y: StrokeWidth + HeightOfTriangle + 0.5),
            radius: BorderRadius - StrokeWidth)
        
        context?.closePath()
        context?.drawPath(using: .fillStroke)
        
        context?.beginPath()
        
        context?.move(to: CGPoint(x: BorderRadius + StrokeWidth, y: round((currentFrame.size.height + HeightOfTriangle)*0.5) + 0.5))
        
        context?.addArc(
            tangent1End: CGPoint(x: currentFrame.size.width - StrokeWidth - 0.5, y: round((currentFrame.size.height + HeightOfTriangle)*0.5) + 0.5) ,
            tangent2End: CGPoint(x: currentFrame.size.width - StrokeWidth - 0.5, y: currentFrame.size.height - StrokeWidth - 0.5),
            radius: BorderRadius - StrokeWidth)
        
        context?.addArc(
            tangent1End: CGPoint(x: currentFrame.size.width - StrokeWidth - 0.5, y: currentFrame.size.height - StrokeWidth - 0.5) ,
            tangent2End: CGPoint(x: round(currentFrame.size.width * 0.5 + WidthOfTriangle * 0.5) - StrokeWidth + 0.5, y: currentFrame.size.height - StrokeWidth - 0.5),
            radius: BorderRadius - StrokeWidth)
        
        context?.addArc(
            tangent1End: CGPoint(x: StrokeWidth + 0.5, y: currentFrame.size.height - StrokeWidth - 0.5),
            tangent2End: CGPoint(x: StrokeWidth + 0.5,y: HeightOfTriangle + StrokeWidth + 0.5),
            radius: BorderRadius - StrokeWidth)
        
        context?.addArc(
            tangent1End: CGPoint(x: StrokeWidth + 0.5, y: round((currentFrame.size.height + HeightOfTriangle) * 0.5) + 0.5),
            tangent2End: CGPoint(x: currentFrame.size.width - StrokeWidth - 0.5, y: round((currentFrame.size.height + HeightOfTriangle) * 0.5) + 0.5),
            radius: BorderRadius - StrokeWidth)
        
        context?.closePath()
        context?.clip()
    }
}
