//
//  ChatViewController.swift
//  MyFirebaseDatabase
//
//  Created by Anthony Rodriguez on 8/16/17.
//  Copyright © 2017 Anthony Rodriguez. All rights reserved.
//

import Foundation
import UIKit
import Firebase

class ChatViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    @IBOutlet weak var tableView:UITableView!
    @IBOutlet weak var textField:UITextField!
    @IBOutlet weak var toolBar:UIToolbar!
    @IBOutlet weak var toolBarBottomConstraints:NSLayoutConstraint!
    var uid:String?
    var originalConstraintValue:CGFloat?
    var messages:[String]?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.originalConstraintValue = toolBarBottomConstraints.constant
        textField.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
        updateMessageTable()
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillAppear(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillDisappear(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        guard let messages = messages else {return 0}
        
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "Cell") else {fatalError("Cell not found!")}
        
        guard let messages = messages else {return cell}
        cell.textLabel?.text = messages[indexPath.row]
        
        return cell
    }
    
    func keyboardWillAppear(_ sender:AnyObject)
    {
        print("Will Appear")
        guard let notificationInfo = (sender as? NSNotification)?.userInfo else {return}
        guard let duration = notificationInfo[UIKeyboardAnimationDurationUserInfoKey] as? Double else {return}
        guard let keyboardFrame = (notificationInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue else {return}
        UIView.animate(withDuration: duration)
        {
            self.toolBarBottomConstraints.constant = keyboardFrame.size.height
            self.view.layoutIfNeeded()
            let offset = CGPoint(x: 0, y: self.tableView.contentSize.height - self.tableView.bounds.size.height)
            self.tableView.setContentOffset(offset, animated: false)
        }
    }
    
    func keyboardWillDisappear(_ sender:AnyObject)
    {
        print("will disapper")
        guard let notificationInfo = (sender as? NSNotification)?.userInfo else {return}
        guard let duration = notificationInfo[UIKeyboardAnimationDurationUserInfoKey] as? Double else {return}
        UIView.animate(withDuration: duration)
        {
            self.toolBarBottomConstraints.constant = self.originalConstraintValue!
            self.view.layoutIfNeeded()
            let offset = CGPoint(x: 0, y: self.tableView.contentSize.height - self.tableView.bounds.size.height)
            self.tableView.setContentOffset(offset, animated: false)
        }
    }
    
    func updateMessageTable()
    {
        guard let uid = self.uid else {return}
        let reference = Database.database().reference()
        let user = reference.child("Users").child(uid)
        user.observeSingleEvent(of: .value, with: {(snapshot) in
            guard let messageLog = snapshot.value as? [String:String] else {return}
            print(messageLog)
            let messages = messageLog.flatMap{$0.value}
            self.messages = messages
            self.tableView.reloadData()
            print(messages)
        })
    }
    
    @IBAction func sendMessage(_ sender:AnyObject)
    {
        guard self.textField.text != "" else {return}
        let text = self.textField.text
        guard let date = DataHandler.getDateTime() else {return}
        guard let uid = self.uid else {return}
        let reference = Database.database().reference()
        let user = reference.child("Users").child(uid)
        user.child(date).setValue(text)
        updateMessageTable()
        self.textField.text = ""
    }
    
    @IBAction func tabGesture(_ sender:AnyObject)
    {
        textField.resignFirstResponder()
    }
}

extension ChatViewController:UITextFieldDelegate
{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        guard string == "\n" else {return true}
        guard textField === self.textField else {return false}
        sendMessage(textField)
        return false
    }
}
